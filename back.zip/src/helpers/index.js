const _isValidRegister = require('./_isValidRegister');
const _isValidLogin = require('./_isValidLogin');

module.exports = {
    _isValidRegister,
    _isValidLogin
}